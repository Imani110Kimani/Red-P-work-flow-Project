<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

This is a React (web) project created with Vite and TypeScript. Please generate code using React functional components, hooks, and modern CSS or CSS-in-JS best practices. Use React Router for navigation. Avoid React Native or mobile-specific APIs.
